
import os,sys
sys.path.insert(0,"..")
from glob import glob
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision
import tqdm
# import sklearn, sklearn.metrics
import torchxrayvision as xrv

# Use XRV transforms to crop and resize the images
transforms = torchvision.transforms.Compose([xrv.datasets.XRayCenterCrop(),
                                             xrv.datasets.XRayResizer(224)])

# Load Google dataset and PyTorch dataloader
dataset = xrv.datasets.NIH_Google_Dataset(imgpath="/Users/ieee8023/Datasets/NIH/images-224",
                                          transform=transforms)
dataloader = torch.utils.data.DataLoader(dataset, batch_size=8, shuffle=True)

# Load pre-trained model and erase classifier
model = xrv.models.DenseNet(weights="densenet121-res224-all")
model.op_threshs = None # prevent pre-trained model calibration
model.classifier = torch.nn.Linear(1024,1) # reinitialize classifier

optimizer = torch.optim.Adam(model.classifier.parameters()) # only train classifier
criterion = torch.nn.BCEWithLogitsLoss()
 

# training loop (can run on cpu)
for i, batch in enumerate(dataloader):
    if i > 20: break
    outputs = model(batch["img"])
    targets = batch["lab"][:, dataset.pathologies.index("Lung Opacity"), None]
    loss = criterion(outputs, targets)
    print(i, loss.detach().cpu().numpy())
    loss.backward()
    optimizer.step()

 
# sample = dataset[0]
# out = model(torch.from_numpy(sample["img"]).unsqueeze(0))
# out = torch.sigmoid(out)

# labels = []
# preds = []
# with torch.inference_mode():
#     for i in range(20):
#         sample = dataset[i]
#         label = sample["lab"][dataset.pathologies.index("Lung Opacity")]
#         labels.append(label)
#         pred = model(torch.from_numpy(sample["img"]).unsqueeze(0))
#         pred = torch.sigmoid(pred).detach().numpy()[0][0]
#         preds.append(pred)
#         print(label, pred)

# sklearn.metrics.roc_auc_score(labels, preds)

 
 